# Someone in class (c) 2014
# Problem 2.1 from Bayesian homework
# Construct a python program to generate random rows of 1 and 0 


import random 

# Number of lines
n = 100

# Probability that a given line is spam
frac_spam = 0.70

# Probability that a ham line contains an exclamation point
frac_ham_excl = 0.35

# Probability that a spam line contains an exclamation point
frac_spam_excl = 0.85


# Function to generate a random number
# Compare random number with the desired probability to return 1 or 0
def generate(p):
    x = random.random()
    if x > p:
        return 0
    else:
        return 1


# Open a new text file to write to
txt_file = open("spam.txt", "w")

# Main for loop, iterate n number of times
for _ in range(n):

    # Make first column ham or spam
    x = generate(frac_spam)
    
    # if Ham
    if x == 0:
        # Determine if second comumn has exclamation point or not
        y = generate(frac_ham_excl)
        # Print columns
        print (x, y)
        # Format line to be written to file
        line = str(x) + " " + str(y) + "\n"
        # Write result to file
        txt_file.write(line)

    else:
        # Similar to above but for spam instead of ham
        y = generate(frac_spam_excl)
        print(x, y)
        line = str(x) + " " + str(y) + "\n"
        txt_file.write(line)


# Close file
txt_file.close()
