# Someone in class (c) 2014
# Problem 2.2 of Bayesian homework

# Please run the gen-email.py file prior to running this file
# in order to generate the text file needed to read from
# Or change input text name to name of file with same input format


# Open text file
txt_file = open("spam.txt", "r")

# Find total number of lines
num_lines = 0
for lines in open("spam.txt"):
    num_lines += 1

# Set initial counts to 0
spam = 0
ham = 0
with_E = 0
no_E = 0
spam_E = 0
ham_E = 0
spam_N = 0
ham_N = 0

# For loop to count outcomes
for _ in range(num_lines):
    # read every line in file
    line = txt_file.readline()

    # if statement to count total spam or ham
    if line[0] == "1":
        spam += 1
    elif line[0] == "0":
        ham += 1
    else:
        # Break and print error if anything other thatn 1 or 0
        print("Incorrect input file format")
        break
    
    # if statement to count exclamation points or not
    if line[2] == "1":
        with_E += 1
    elif line[2] == "0":
        no_E += 1
    else:
        print("Incorrect input file format")
        break

    # if statement to count exclamation points or not with spam or ham
    if line[0] == "1" and line[2] == "1":
        spam_E += 1
    elif line[0] == "0" and line[2] == "1":
        ham_E += 1
    elif line[0] == "1" and line[2] == "0":
        spam_N += 1
    elif line[0] == "0" and line[2] == "0":
        ham_N += 1
    else:
        pass

# Close file
txt_file.close()

# Calculate probabilities
pr_E = with_E / num_lines
pr_N = no_E / num_lines
pr_S = spam / num_lines
pr_H = ham / num_lines
pr_E_S = spam_E / spam
pr_E_H = ham_E / ham
pr_N_S = spam_N / spam
pr_N_H = ham_N / ham


# Bayesian Calculations 
pr_S_E = pr_E_S * pr_S / pr_E
pr_H_E = pr_E_H * pr_H / pr_E
pr_S_N = pr_N_S * pr_S / pr_N
pr_H_N = pr_N_H * pr_H / pr_N

# Display result in table
print("    N    E")
print("H %.2f %.2f" %(pr_H_N, pr_H_E))
print("S %.2f %.2f" %(pr_S_N, pr_S_E))

